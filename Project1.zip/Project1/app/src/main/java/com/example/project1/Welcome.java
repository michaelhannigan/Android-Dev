package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Welcome extends AppCompatActivity {

    private TextView welcomeUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        welcomeUsername = findViewById(R.id.welcome);
        Intent intent = getIntent();
        String message = "Welcome " + intent.getStringExtra("Info") + "!";
        welcomeUsername.setText(message);

    }
}